class MyException(Exception):
    pass
